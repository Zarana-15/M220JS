require("@babel/register")
require("dotenv").config()

exports = module.exports = require("./src")
